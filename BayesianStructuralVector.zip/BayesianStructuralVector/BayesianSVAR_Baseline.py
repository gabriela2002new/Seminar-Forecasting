import pymc as pm
import numpy as np
import arviz as az
import BayesianSVAR
import matplotlib.pyplot as plt
import pandas as pd
import pytensor.tensor as tt
from numpy.array_api import positive
from numpy.ma.core import negative
from sklearn.preprocessing import StandardScaler


def main():
    try:
        print("Starting main()...")

        columns = [
            'Brent_logdiff',
            'Gas Prices_logdiff',
            'growth_rate_inflation',
            'DSPIC96_log_diff',
            'EUR-USD_logdiff',

        ]
        columns = columns
        file_path = r'C:\Users\acer\PycharmProjects\PreprocessingOfData\Stationary_data_mine (15).xlsx'

        print("Loading data...")
        df = BayesianSVAR.load_data(file_path)
        print("Data loaded.")

        start_date = '2015-01'
        end_date = '2024-01'

        print("Filtering and scaling data...")
        filtered_df = BayesianSVAR.filter_data(df, start_date, end_date, columns)
        filtered_df = BayesianSVAR.scale_columns(filtered_df, columns)
        print("Filtered Data shape:", filtered_df.shape)

        data_array = filtered_df.values.astype(np.float64)
        n_vars = data_array.shape[1]

        # Build model with a 10-horizon positivity restriction for all i,j
        horizon = 10


        print("Defining SVAR model...")
        model = BayesianSVAR.define_svar_model(data_array, horizon=horizon, impose_all_positive=True)
        print("Model defined.")

        with model:
            print("Starting sampling...")
            trace = pm.sample(500, tune=500, target_accept=0.9, return_inferencedata=True, random_seed=42)
            print("Sampling complete.")

        # Summary of the posterior
        print("Generating summary...")
        summary = az.summary(trace, var_names=["B", "chol_det"])
        print(summary)

        # Post-hoc IRF plotting
        posterior_B = trace.posterior["B"].values  # shape (chain, draw, n, n)
        posterior_chol = trace.posterior["chol_det"].values
        combined_B = posterior_B.reshape(-1, n_vars, n_vars)
        combined_chol = posterior_chol.reshape(-1, n_vars, n_vars)
        n_samples = combined_B.shape[0]

        print("Plotting IRFs...")
        response_idx = 2
        shock_indices = [0, 1, 3, 4]
        BayesianSVAR.plot_irfs_combined(
            n_samples, combined_B, combined_chol,
            response_idx, shock_indices, horizon, columns
        )
        print("IRF plots complete.")

        print("Running rolling SVAR forecast...")
        window_size = 94
        lags = 1
        results = BayesianSVAR.rolling_svar_forecast_bayesian_steps(
            filtered_df,
            window_size,
            steps_ahead=1,
            impose_all_positive=True,
            num_samples=500,
            num_tune=500
        )

        forecast_df = pd.DataFrame([
            {
                "start": res["start_index"],
                "end": res["end_index"],
                **{f"var_{i}": val for i, val in enumerate(res["forecast"])}
            }
            for res in results if res is not None
        ])

        print(forecast_df.head())

        print("Forecasting complete.")

    except Exception as e:
        print(f"An error occurred: {e}")

    BayesianSVAR.plot_forecasts_with_ci(results,filtered_df,'growth_rate_inflation',var_index=2)

    # Evaluate and plot
    rmse = BayesianSVAR.compute_rmse_rolling(results, filtered_df, 'growth_rate_inflation')
    print(f"RMSE for 'growth rate inflation': {rmse:.4f}")



if __name__ == "__main__":
    main()


