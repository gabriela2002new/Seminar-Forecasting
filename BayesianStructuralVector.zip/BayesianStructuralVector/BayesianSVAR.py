import pymc as pm
import numpy as np
import arviz as az
import matplotlib.pyplot as plt
import pandas as pd
import pytensor.tensor as tt
from numpy.array_api import positive
from numpy.ma.core import negative
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error



# -----------------------------
# 1. Load & filter your dataset
# -----------------------------
def load_data(file_path):
    df = pd.read_excel(file_path, engine='openpyxl')
    df['Months'] = pd.to_datetime(df['Months'], errors='coerce')
    df = df[~df['Months'].isna()]
    df.set_index('Months', inplace=True)
    df.sort_index(inplace=True)
    return df


def filter_data(df, start_date, end_date, columns):
    df_filtered = df[start_date:end_date]
    return df_filtered[columns].dropna()

def scale_columns(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Scales the specified columns of a DataFrame using StandardScaler.

    Parameters:
        df (pd.DataFrame): The original DataFrame.
        columns (list): List of column names to scale.

    Returns:
        pd.DataFrame: A new DataFrame with the specified columns scaled.
    """
    scaler = StandardScaler()
    df_scaled = df.copy()
    df_scaled[columns] = scaler.fit_transform(df[columns])

    return df_scaled

# --------------------------------------------------------------------
# 2. A function to compute IRFs in pytensor, so we can apply a Potential
# --------------------------------------------------------------------
def compute_irf_tt(B, chol, horizon):
    """
    Compute B^h @ chol for h in 0..horizon using pytensor operations.
    Return a tensor of shape (horizon+1, n_vars, n_vars),
    where [h, i, j] = IRF of i responding to shock j at horizon h.
    """
    n = B.shape[0]

    # We'll store IRFs across h=0..H in a list, then stack them at the end
    A_power = tt.eye(n)
    irfs = []
    for h in range(horizon + 1):
        irf_matrix = tt.dot(A_power, chol)  # shape (n, n)
        irfs.append(irf_matrix)
        A_power = tt.dot(A_power, B)  # A_power = B^h accumulates

    # Stack along a new 0th dimension for horizon
    # The result is shape (horizon+1, n, n)
    irfs_3d = tt.stack(irfs, axis=0)
    return irfs_3d


# ------------------------------------------
# 3. Define the Bayesian VAR(1) with sign restrictions for all pairs
# ------------------------------------------
def define_svar_model(data, horizon=10, impose_all_positive=True):
    """
    If impose_all_positive=True, then IRFs for all i, j in 0..(n-1)
    must be positive for all horizons 0..horizon.
    """
    T, n_vars = data.shape
    X = data[:-1]
    Y = data[1:]

    with pm.Model() as model:
        # B: Coefficients matrix (n_vars x n_vars)
        B = pm.Normal('B', mu=0, sigma=1, shape=(n_vars, n_vars))

        # Covariance prior (LKJ)
        chol, corr, stds = pm.LKJCholeskyCov(
            'Sigma', n=n_vars, eta=2.0,
            sd_dist=pm.HalfNormal.dist(1.0),
            compute_corr=True
        )
        pm.Deterministic("chol_det", chol)

        # Likelihood
        mu = pm.math.dot(X, B.T)
        pm.MvNormal('Y_obs', mu=mu, chol=chol, observed=Y)

        if impose_all_positive:
            # Compute IRFs for all horizons
            irfs_3d = compute_irf_tt(B, chol, horizon)  # shape: (horizon+1, n_vars, n_vars)

            # Flatten out so we can check positivity on all elements:
            # shape: ( (horizon+1) * n_vars * n_vars, )
            irfs_flat = irfs_3d.reshape([(horizon + 1) * n_vars * n_vars])

            # Impose positivity on all IRF elements
            condition_all_pos = tt.all(irfs_flat > 0)
            pm.Potential("all_irf_signs", tt.switch(condition_all_pos, 0, -1e9))

        # If you only wanted positivity for certain (i, j), you'd do partial loops or conditions.

    return model


def define_svar_model_different(data, horizon=10, positive_signs=None, negative_signs=None):
    """
    positive_signs: list of (i, j) tuples to impose IRF[i, j] > 0
    negative_signs: list of (i, j) tuples to impose IRF[i, j] < 0
    All constraints apply over all horizons 0..horizon
    """
    if positive_signs is None:
        positive_signs = []
    if negative_signs is None:
        negative_signs = []

    T, n_vars = data.shape
    X = data[:-1]
    Y = data[1:]

    with pm.Model() as model:
        # B: Coefficients matrix (n_vars x n_vars)
        B = pm.Normal('B', mu=0, sigma=1, shape=(n_vars, n_vars))

        # Covariance prior (LKJ)
        chol, corr, stds = pm.LKJCholeskyCov(
            'Sigma', n=n_vars, eta=2.0,
            sd_dist=pm.HalfNormal.dist(1.0),
            compute_corr=True
        )
        pm.Deterministic("chol_det", chol)

        # Likelihood
        mu = pm.math.dot(X, B.T)
        pm.MvNormal('Y_obs', mu=mu, chol=chol, observed=Y)

        # Compute IRFs for all horizons
        irfs_3d = compute_irf_tt(B, chol, horizon)  # shape: (horizon+1, n_vars, n_vars)

        # Apply sign restrictions for specified entries
        for t in range(horizon + 1):
            for i, j in positive_signs:
                cond = irfs_3d[t, i, j] > 0
                pm.Potential(f"pos_t{t}_i{i}_j{j}", tt.switch(cond, 0, -1e9))
            for i, j in negative_signs:
                cond = irfs_3d[t, i, j] < 0
                pm.Potential(f"neg_t{t}_i{i}_j{j}", tt.switch(cond, 0, -1e9))

    return model


def define_svar_Cholesky_restrictions(data, horizon=10,
                                      positive_indices=None, negative_indices=None,positive_signs=None,negative_signs=None):
    """
    Define a SVAR model where sign restrictions are applied to the inverse of the Cholesky factor.

    The idea is:
      1. Obtain the Cholesky factor L such that Σ = L Lᵀ.
      2. Compute the inverse: L⁻¹.
      3. Impose sign restrictions on L⁻¹ (e.g., force certain elements to be positive or negative).
      4. Invert the sign-restricted L⁻¹ to recover a new Cholesky factor L* that reflects these restrictions.

    Parameters:
      data:             Observed data (NumPy array of shape (T, n_vars)).
      horizon:          The horizon for the impulse responses.
      positive_indices: List of tuples (i, j) indicating positions in the inverse that must be positive.
      negative_indices: List of tuples (i, j) indicating positions in the inverse that must be negative.

    Returns:
      A PyMC3 model.
    """
    # Set default indices if not provided.
    if positive_indices is None:
        positive_indices = []
    if negative_indices is None:
        negative_indices = []

    T, n_vars = data.shape
    X = data[:-1]  # predictors
    Y = data[1:]  # response

    with pm.Model() as model:
        # 1. Define the coefficients matrix for the VAR.
        B = pm.Normal('B', mu=0, sigma=1, shape=(n_vars, n_vars))

        # 2. Define the covariance prior using LKJCholeskyCov.
        # Note: Depending on settings (e.g., compute_corr=True), this might return a full lower-triangular matrix.
        chol_out, corr, stds = pm.LKJCholeskyCov(
            'Sigma', n=n_vars, eta=2.0,
            sd_dist=pm.HalfNormal.dist(1.0),
            compute_corr=True
        )

        # 3. If the returned Cholesky factor is packed (1D), expand it to a full lower-triangular matrix.
        if chol_out.ndim == 1:
            chol_full = pm.expand_packed_triangular(n_vars, chol_out, lower=True)
        else:
            chol_full = chol_out  # already full.

        # 4. Compute the inverse of the Cholesky factor.
        #    Note: We use a triangular solver for numerical stability.

        # 5. Define a helper function to impose sign restrictions.
        def impose_signs(matrix):
            # This function loops over all elements in the matrix and applies sign restrictions.
            corrected = matrix
            for i in range(n_vars):
                for j in range(n_vars):
                    if (i, j) in positive_indices:
                        # If the element is negative, force it to be positive.
                        corrected = tt.set_subtensor(
                            corrected[i, j],
                            tt.switch(matrix[i, j] <0, -matrix[i, j], matrix[i, j])
                        )
                    elif (i, j) in negative_indices:
                        # If the element is positive, force it to be negative.
                        corrected = tt.set_subtensor(
                            corrected[i, j],
                            tt.switch(matrix[i, j] > 0, -matrix[i, j], matrix[i, j])
                        )
            return corrected

        # 6. Apply the sign restrictions to the inverse of the Cholesky matrix.
        #    This produces a "restricted inverse" that meets your sign requirements.
        chol_restricted = impose_signs(chol_full)

        # 7. Recover the new Cholesky factor by inverting the restricted inverse.
        #    This new factor is our sign-corrected Cholesky factor.
        chol_corrected = tt.linalg.inv(chol_restricted )


        # For inspection, record the sign-corrected Cholesky factor.
        pm.Deterministic("chol_det", chol_corrected)

        # 8. Recover the corresponding covariance matrix: Σ = L* L*ᵀ.
        #    Here we give it a unique name to avoid conflicts.
        Sigma_new = pm.Deterministic('Sigma_new', pm.math.dot(chol_corrected, chol_corrected.T))

        # 9. Define the likelihood for the VAR.
        mu = pm.math.dot(X, B.T)
        pm.MvNormal('Y_obs', mu=mu, chol=chol_corrected, observed=Y)

        # 10. Compute the impulse response functions using the new sign-restricted matrices.
        irfs_3d = compute_irf_tt(B, chol_corrected, horizon)
        # Apply sign restrictions for specified entries
        for t in range(horizon + 1):
            for i, j in positive_signs:
                cond = irfs_3d[t, i, j] > 0
                pm.Potential(f"pos_t{t}_i{i}_j{j}", tt.switch(cond, 0, -1e9))
            for i, j in negative_signs:
                cond = irfs_3d[t, i, j] < 0
                pm.Potential(f"neg_t{t}_i{i}_j{j}", tt.switch(cond, 0, -1e9))

    return model

def define_svar_Cholesky_restrictions_D(data, horizon=10,
                                      positive_indices=None, negative_indices=None,positive_signs=None,negative_signs=None):
    """
    Define a SVAR model where sign restrictions are applied to the inverse of the Cholesky factor.

    The idea is:
      1. Obtain the Cholesky factor L such that Σ = L Lᵀ.
      2. Compute the inverse: L⁻¹.
      3. Impose sign restrictions on L⁻¹ (e.g., force certain elements to be positive or negative).
      4. Invert the sign-restricted L⁻¹ to recover a new Cholesky factor L* that reflects these restrictions.

    Parameters:
      data:             Observed data (NumPy array of shape (T, n_vars)).
      horizon:          The horizon for the impulse responses.
      positive_indices: List of tuples (i, j) indicating positions in the inverse that must be positive.
      negative_indices: List of tuples (i, j) indicating positions in the inverse that must be negative.

    Returns:
      A PyMC3 model.
      :param negative_signs:
      :param positive_indices:
      :param negative_indices:
      :param positive_signs:
    """
    # Set default indices if not provided.
    if positive_indices is None:
        positive_indices = []
    if negative_indices is None:
        negative_indices = []

    T, n_vars = data.shape
    X = data[:-1]  # predictors
    Y = data[1:]  # response

    with pm.Model() as model:
        # 1. Define the coefficients matrix for the VAR.
        B = pm.Normal('B', mu=0, sigma=1, shape=(n_vars, n_vars))

        # 2. Define the covariance prior using LKJCholeskyCov.
        # Note: Depending on settings (e.g., compute_corr=True), this might return a full lower-triangular matrix.
        chol_out, corr, stds = pm.LKJCholeskyCov(
            'Sigma', n=n_vars, eta=2.0,
            sd_dist=pm.HalfNormal.dist(1.0),
            compute_corr=True
        )

        # 3. If the returned Cholesky factor is packed (1D), expand it to a full lower-triangular matrix.
        if chol_out.ndim == 1:
            chol_full = pm.expand_packed_triangular(n_vars, chol_out, lower=True)
        else:
            chol_full = chol_out  # already full.

        # 4. Compute the inverse of the Cholesky factor.
        #    Note: We use a triangular solver for numerical stability.

        # 5. Define a helper function to impose sign restrictions.
        def impose_signs(matrix):
            # This function loops over all elements in the matrix and applies sign restrictions.
            corrected = matrix
            for i in range(n_vars):
                for j in range(n_vars):
                    if (i, j) in positive_indices:
                        # If the element is negative, force it to be positive.
                        corrected = tt.set_subtensor(
                            corrected[i, j],
                            tt.switch(matrix[i, j] <0, -matrix[i, j], matrix[i, j])
                        )
                    elif (i, j) in negative_indices:
                        # If the element is positive, force it to be negative.
                        corrected = tt.set_subtensor(
                            corrected[i, j],
                            tt.switch(matrix[i, j] > 0, -matrix[i, j], matrix[i, j])
                        )
            return corrected

        # 6. Apply the sign restrictions to the inverse of the Cholesky matrix.
        #    This produces a "restricted inverse" that meets your sign requirements.
        chol_restricted = impose_signs(chol_full)

        # 7. Recover the new Cholesky factor by inverting the restricted inverse.
        #    This new factor is our sign-corrected Cholesky factor.


        # For inspection, record the sign-corrected Cholesky factor.
        pm.Deterministic("chol_det", chol_restricted)

        # 8. Recover the corresponding covariance matrix: Σ = L* L*ᵀ.
        #    Here we give it a unique name to avoid conflicts.
        Sigma_new = pm.Deterministic('Sigma_new', pm.math.dot(chol_restricted, chol_restricted.T))

        # 9. Define the likelihood for the VAR.
        mu = pm.math.dot(X, B.T)
        pm.MvNormal('Y_obs', mu=mu, chol=chol_restricted, observed=Y)

        # 10. Compute the impulse response functions using the new sign-restricted matrices.
        irfs_3d = compute_irf_tt(B, chol_restricted, horizon)
        # Apply sign restrictions for specified entries
        for t in range(horizon + 1):
            for i, j in positive_signs:
                cond = irfs_3d[t, i, j] > 0
                pm.Potential(f"pos_t{t}_i{i}_j{j}", tt.switch(cond, 0, -1e9))
            for i, j in negative_signs:
                cond = irfs_3d[t, i, j] < 0
                pm.Potential(f"neg_t{t}_i{i}_j{j}", tt.switch(cond, 0, -1e9))

    return model
# ------------------------------------------
# 4. Compute IRFS
# ------------------------------------------

def compute_irf_np(B, chol, horizon):
        n = B.shape[0]
        A_power = np.eye(n)
        matrices = []
        for h in range(horizon + 1):
            matrices.append(A_power @ chol)
            A_power = A_power @ B
        return np.array(matrices)  # shape: (horizon+1, n, n)

# ------------------------------------------
# 5. Plot IRFS
# ------------------------------------------

def plot_irfs(n_samples,combined_B,combined_chol,response_idx,shock_idx,horizon,columns):
    all_irfs = np.zeros((n_samples, horizon + 1))
    for s in range(n_samples):
        mat_3d = compute_irf_np(combined_B[s], combined_chol[s], horizon)
        # mat_3d[h, i, j] = IRF of variable i to shock j at horizon h
        all_irfs[s, :] = mat_3d[:, response_idx, shock_idx]

    mean_irf = np.mean(all_irfs, axis=0)
    lower_irf = np.percentile(all_irfs, 2.5, axis=0)
    upper_irf = np.percentile(all_irfs, 97.5, axis=0)

    horizons = np.arange(horizon + 1)
    plt.figure(figsize=(8, 5))
    plt.plot(horizons, mean_irf, label="Mean IRF", marker='o')
    plt.fill_between(horizons, lower_irf, upper_irf, alpha=0.3, label="95% CI")
    plt.axhline(0, color="black", linestyle="--", linewidth=1)
    plt.xlabel("Horizon")
    plt.ylabel(f"Response of {columns[response_idx]}")
    plt.title(f"IRF of {columns[response_idx]} to shock in {columns[shock_idx]}")
    plt.legend()
    plt.show()

# ------------------------------------------
# 6. Plot IRFS
# ------------------------------------------

def plot_irfs_combined(n_samples, combined_B, combined_chol, response_idx, shock_indices, horizon,columns):
    import numpy as np
    import matplotlib.pyplot as plt



    horizons = np.arange(horizon + 1)
    plt.figure(figsize=(10, 6))

    for shock_index in shock_indices:
        all_irfs = np.zeros((n_samples, horizon + 1))
        for s in range(n_samples):
            mat_3d = compute_irf_np(combined_B[s], combined_chol[s], horizon)
            all_irfs[s, :] = mat_3d[:, response_idx, shock_index]

        mean_irf = np.mean(all_irfs, axis=0)
        lower_irf = np.percentile(all_irfs, 2.5, axis=0)
        upper_irf = np.percentile(all_irfs, 97.5, axis=0)

        plt.plot(horizons, mean_irf, label=f"Shock: {columns[shock_index]}", marker='o')
        plt.fill_between(horizons, lower_irf, upper_irf, alpha=0.2)

    plt.axhline(0, color="black", linestyle="--", linewidth=1)
    plt.xlabel("Horizon")
    plt.ylabel(f"Response of {columns[response_idx]}")
    plt.title(f"IRFs of {columns[response_idx]} to Different Shocks")
    plt.legend()
    plt.tight_layout()
    plt.show()


# ---------------------------
# Forecast using no window
# ---------------------------
def forecast_values(posterior_B, posterior_chol, last_observed_data, horizon, n_samples):
    """
    Forecast actual values for the next `horizon` months based on posterior samples of B and chol.

    Parameters:
        posterior_B: (n_samples, n_vars, n_vars) posterior samples of VAR coefficients
        posterior_chol: (n_samples, n_vars, n_vars) posterior samples of Cholesky decomposition
        last_observed_data: (n_vars,) the most recent observed values (at the end of the training period)
        horizon: (int) the number of periods to forecast
        n_samples: (int) number of posterior samples

    Returns:
        forecasted_values: (n_samples, horizon, n_vars) simulated forecasted values for each posterior sample
    """
    forecasted_values = np.zeros((n_samples, horizon, last_observed_data.shape[0]))

    # Simulate future values for each posterior sample
    for s in range(n_samples):
        B_sample = posterior_B[s]
        chol_sample = posterior_chol[s]

        # Start with the last observed data point
        forecasted_values[s, 0, :] = np.dot(last_observed_data, B_sample.T)  # Forecast for next period

        for t in range(1, horizon):
            forecasted_values[s, t, :] = np.dot(forecasted_values[s, t - 1, :], B_sample.T)

    return forecasted_values






def plot_forecasted_values(forecasted_values, horizon, response_idx,columns):
    """
    Plot the forecasted values with 95% credible interval.

    Parameters:
        forecasted_values: (n_samples, horizon, n_vars) forecasted values
        horizon: (int) the number of forecast periods
        response_idx: (int) index of the response variable (e.g., inflation)
    """

    mean_forecast = np.mean(forecasted_values, axis=0)
    lower_forecast = np.percentile(forecasted_values, 2.5, axis=0)
    upper_forecast = np.percentile(forecasted_values, 97.5, axis=0)

    horizons = np.arange(1, horizon + 1)
    plt.figure(figsize=(8, 5))
    plt.plot(horizons, mean_forecast[:, response_idx], label="Mean Forecast", marker='o')
    plt.fill_between(horizons, lower_forecast[:, response_idx], upper_forecast[:, response_idx], alpha=0.3,
                     label="95% CI")
    plt.axhline(0, color="black", linestyle="--", linewidth=1)
    plt.xlabel("Horizon (Months)")
    plt.ylabel(f"Forecasted Value of {columns[response_idx]}")
    plt.title(f"Forecast of {columns[response_idx]} for the next 12 months")
    plt.legend()
    plt.show()


def plot_forecasts_vs_actuals(forecasted_values, df_actual, horizon,inflation_column, response_idx,columns):
    """
    Plot both the forecasted and actual values for comparison.

    Parameters:
        forecasted_values: (n_samples, horizon, n_vars) forecasted values
        actual_values: (horizon, n_vars) actual values of inflation (or any variable you're forecasting)
        horizon: (int) the number of forecast periods
        response_idx: (int) index of the response variable (e.g., inflation)
    """
    mean_forecast = np.mean(forecasted_values, axis=0)
    lower_forecast = np.percentile(forecasted_values, 2.5, axis=0)
    upper_forecast = np.percentile(forecasted_values, 97.5, axis=0)

    horizons = np.arange(1, horizon + 1)

    # Ensure actual_values is a NumPy array for easy indexing
    actual_series = df_actual[inflation_column].iloc[:horizon]

    plt.figure(figsize=(10, 6))

    # Plot actual inflation
    plt.plot(horizons, actual_series, label="Actual Inflation", color='blue', marker='o', linestyle='-', linewidth=2)

    # Plot forecasted inflation with 95% credible interval
    plt.plot(horizons, mean_forecast[:, response_idx], label="Mean Forecast", marker='o', color='orange')
    plt.fill_between(horizons, lower_forecast[:, response_idx], upper_forecast[:, response_idx], alpha=0.3,
                     color='orange', label="95% CI")

    plt.axhline(0, color="black", linestyle="--", linewidth=1)
    plt.xlabel("Horizon (Months)")
    plt.ylabel(f"Value of {columns[response_idx]}")
    plt.title(f"Comparison of Forecasted vs Actual Values of {columns[response_idx]} for the Next 12 Months")
    plt.legend()
    plt.tight_layout()
    plt.show()






def compute_rmse(forecasted_values, df_actual, horizon, inflation_column, response_idx):
    """
    Compute the Root Mean Squared Error (RMSE) for each forecast step up to the horizon.

    Parameters:
        forecasted_values (np.ndarray): Array of shape (n_samples, horizon, n_vars).
        df_actual (pd.DataFrame): DataFrame containing actual observed values.
        horizon (int): Number of forecast periods.
        inflation_column (str): Name of the actual value column in df_actual.
        response_idx (int): Index of the response variable in forecasted_values.

    Returns:
        list: RMSE values for each forecast horizon step (from 1 to horizon).
    """
    # Mean forecast across samples
    mean_forecast = np.mean(forecasted_values, axis=0)[:, response_idx]

    # Actual observed values
    actual = df_actual[inflation_column].iloc[:horizon].values

    # Compute RMSE for each time step from 1 to horizon
    rmse_per_step = []
    for h in range(1, horizon + 1):
        rmse = np.sqrt(np.mean((mean_forecast[:h] - actual[:h]) ** 2))
        rmse_per_step.append(rmse)

    return rmse_per_step

#---------------------------------------------------------------------------------------------------------------------------
#Forecasting for the rolling window
#--------------------------------------------------------------------------------------------------------------------------
def rolling_svar_forecast_bayesian_steps(data, window_size, steps_ahead=1, impose_all_positive=True, num_samples=500, num_tune=500):
    """
    Run rolling window Bayesian SVAR estimation and compute multi-step-ahead forecasts.

    Parameters:
    -----------
    data : pd.DataFrame
        Time series data.
    window_size : int
        Size of rolling window.
    steps_ahead : int
        Number of steps ahead to forecast.
    impose_all_positive : bool
        Whether to impose all-positive IRF constraints.
    num_samples : int
        Number of MCMC samples.
    num_tune : int
        Tuning steps for NUTS sampler.

    Returns:
    --------
    results_list : list of dict
        Each dict contains 'trace', 'forecast', 'start_index', 'end_index'.
    """
    results_list = []
    n_obs = data.shape[0]
    n_vars = data.shape[1]

    for start in range(n_obs - window_size + 1 - steps_ahead):
        end = start + window_size
        window_data = data.iloc[start:end].values

        try:
            # Define and sample from the Bayesian SVAR model
            model = define_svar_model(window_data, impose_all_positive=impose_all_positive)
            with model:
                trace = pm.sample(draws=num_samples, tune=num_tune, target_accept=0.9, progressbar=False)

            # Extract last observation from window
            last_obs = window_data[-1].reshape(1, -1)  # shape: (1, n_vars)

            # Posterior mean of B
            B_post = trace.posterior['B'].stack(sample=("chain", "draw")).mean(dim='sample').values
            chol_post = trace.posterior['chol_det'].stack(sample=("chain", "draw")).mean(dim='sample').values

            # Forecast iteratively for the given number of steps
            for step in range(steps_ahead):
                forecast_mean = np.dot(last_obs, B_post.T)
                last_obs = forecast_mean.reshape(1, -1)

            # Append only the final step's forecast
            results_list.append({
                "trace": trace,
                "forecast": forecast_mean.flatten(),  # Only the last step
                "start_index": start,
                "end_index": end,
                "forecast_step_index": end + steps_ahead - 1,
            })

        except Exception as e:
            print(f"Bayesian SVAR window {start}-{end} failed: {e}")
            results_list.append(None)

    # Print forecasts after rolling estimation
    for i, result in enumerate(results_list):
        if result is not None:
            print(f"Window {i}: {result['start_index']} to {result['end_index']}")
            print(f"Forecast (step {steps_ahead} ahead): {result['forecast']}\n")
        else:
            print(f"Window {i}: Forecast failed.\n")

    return results_list

def plot_forecasts_with_ci(results_list, actual_data, target_column, var_index):
    """
    Plot forecast vs actual with 95% CI for a given variable index or name.

    Parameters:
    -----------
    results_list : list
        Output from rolling_svar_forecast_bayesian_steps.
    actual_data : pd.DataFrame
        Full dataset.
    target_column : int or str
        Which variable to plot (column index or column name in the DataFrame).
    var_index : int
        Index of the variable in forecast arrays.
    """
    forecast_means = []
    forecast_lowers = []
    forecast_uppers = []
    actuals = []
    dates = []

    for res in results_list:
        if res is not None:
            idx = res["forecast_step_index"]
            if idx < len(actual_data):
                # Forecast mean for the last step
                forecast_mean = res["forecast"][var_index]
                forecast_means.append(forecast_mean)

                # Extract posterior samples of B
                trace = res["trace"]
                B_samples = trace.posterior['B'].stack(sample=("chain", "draw")).values  # shape: (n_vars, n_vars)
                B_samples = B_samples.transpose(2, 0, 1)  # (samples, n_vars, n_vars)

                # Get the last observed value from the estimation window
                last_obs = actual_data.iloc[res["end_index"] - 1].values.reshape(1, -1)  # shape: (1, n_vars)

                # Generate predictive distribution for 1-step-ahead
                preds = np.einsum("ij,sji->s", last_obs, B_samples)  # shape: (samples,)

                lower = np.percentile(preds, 2.5)
                upper = np.percentile(preds, 97.5)

                forecast_lowers.append(lower)
                forecast_uppers.append(upper)

                # Actual value
                if isinstance(target_column, int):
                    actual_val = actual_data.iloc[idx, target_column]
                else:
                    actual_val = actual_data.iloc[idx][target_column]

                actuals.append(actual_val)
                dates.append(actual_data.index[idx])

    # Plotting
    plt.figure(figsize=(12, 6))
    plt.plot(dates, actuals, label="Actual", color="black")
    plt.plot(dates, forecast_means, label="Forecast", color="blue")
    plt.fill_between(dates, forecast_lowers, forecast_uppers, color="blue", alpha=0.3, label="95% CI")
    plt.title(f"Forecast vs Actual - Variable {target_column}")
    plt.xlabel("Time")
    plt.ylabel("Value")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def compute_rmse_rolling(results_list, actual_data, target_column):
    """
    Compute RMSE of the forecasts against actual data for a specific column.

    Parameters:
    -----------
    results_list : list
        Output from rolling_svar_forecast_bayesian_steps.
    actual_data : pd.DataFrame
        Original time series data.
    target_column : int or str
        Index or name of the column to compute RMSE for.

    Returns:
    --------
    rmse : float
        Root Mean Squared Error.
    """
    forecasts = []
    actuals = []

    for res in results_list:
        if res is not None:
            forecast_idx = res["forecast_step_index"]
            if forecast_idx < len(actual_data):
                forecast_array = res["forecast"]  # shape: (n_vars,)

                if isinstance(target_column, int):
                    forecast_val = forecast_array[target_column]
                    actual_val = actual_data.iloc[forecast_idx, target_column]
                else:
                    col_idx = actual_data.columns.get_loc(target_column)
                    forecast_val = forecast_array[col_idx]
                    actual_val = actual_data.iloc[forecast_idx][target_column]

                forecasts.append(forecast_val)
                actuals.append(actual_val)

    mse = mean_squared_error(actuals, forecasts)
    rmse = np.sqrt(mse)

    return rmse


import os

def save_results_to_file(summary, forecasted_values, rmse,mean_forecast,lower_forecast,upper_forecast, output_path='output_results.txt'):
    with open(output_path, 'w') as f:
        f.write("==== Summary of Trace ====\n")
        f.write(summary.to_string())  # az.summary returns a DataFrame
        f.write("\n\n==== Forecasted Values (Inflation) ====\n")
        f.write(str(forecasted_values[:, 2]))  # Assuming response_idx=2
        f.write("\n\n==== RMSE ====\n")
        f.write(str(rmse))
        f.write("\n\n==== mean_forecast ====\n")
        f.write(str(mean_forecast))
        f.write("\n\n==== lower_forecast(2.5) ====\n")
        f.write(str(lower_forecast))
        f.write("\n\n==== upper_forecast(97.5) ====\n")
        f.write(str(upper_forecast))
    print(f"\nResults saved to: {os.path.abspath(output_path)}")

