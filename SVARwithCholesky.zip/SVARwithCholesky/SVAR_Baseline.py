import Functions
from sklearn.metrics import mean_squared_error
from scipy.stats import boxcox
from sklearn.preprocessing import StandardScaler
import numpy as np
import pandas as pd


from statsmodels.tsa.api import VAR, SVAR

import matplotlib.pyplot as plt



def main():
    # -----------------------------------------------
    # Step 1: Load and Filter Data
    # -----------------------------------------------

    file_path = r'C:\Users\acer\PycharmProjects\PreprocessingOfData\Stationary_data_mine (13).xlsx'
    df = Functions.load_data(file_path)

    start_date = '2015-01'
    end_date = '2024-01'

    columns = [
        'Brent_logdiff',
        'Gas Prices_logdiff',
        'growth_rate_inflation',
        'DSPIC96_log_diff',
        'EUR-USD_logdiff',

    ]

    df_estimation = Functions.filter_data(df, start_date, end_date, columns)
    Functions.test_stationarity(df_estimation, columns)
    df_estimation, scaler = Functions.scale_columns(df_estimation, columns)

    # -----------------------------------------------
    # Step 2: Estimate the VAR Model (initial, for IRFs, shocks, etc.)
    # -----------------------------------------------

    var_results = Functions.estimate_var_model(df_estimation)
    residuals, cov_matrix, C_inf = Functions.compute_matrices(var_results)

    restrictions = Functions.convert_named_to_index_restrictions(
        Functions.define_named_sign_restrictions(), columns)

    optimized_chol_matrix = Functions.optimize_matrix(cov_matrix, C_inf, restrictions)
    structural_shocks = Functions.compute_structural_shocks(residuals, optimized_chol_matrix)

    num_periods = 100
    all_shocks_indices = [0, 1, 3, 4]
    inflation_index = 2

    all_shocks_irfs = Functions.compute_side_IRF(columns, num_periods, all_shocks_indices,
                                                  structural_shocks, inflation_index)
    Functions.plot_side_shocks(all_shocks_indices, columns, all_shocks_irfs)

    structural_irfs = Functions.compute_IRF(columns, num_periods, structural_shocks)

    cost_push_indices = [0, 1]
    cost_push_irfs_per_period = Functions.augmented_IRFS(num_periods, structural_irfs,
                                                          inflation_index, cost_push_indices)

    label = "Sum of Cost-Push IRFs on Inflation"
    title = "Cumulative Response of Inflation to Cost-Push Shocks"
    Functions.plot_augumented_IRFS(cost_push_irfs_per_period, label, title)

    print("Optimized Structural Matrix (Cholesky Decomposition):")
    print(optimized_chol_matrix)

    C_inf_D = C_inf @ optimized_chol_matrix
    print("\nLong-run impact matrix (C(∞) * D):")
    print(C_inf_D)

    fevd_inflation = Functions.compute_FEVD(num_periods, columns, structural_irfs, inflation_index)
    Functions.plot_FEVD(columns, fevd_inflation)


    # -----------------------------------------------
    # Step 10: Rolling One-Step-Ahead Forecasting
    # -----------------------------------------------

    window_size = 80
    lags = 1
    results = Functions.rolling_svar_forecast(df_estimation, window_size, lags, steps_ahead=1)

    for result in results:
        if result is not None:
            print("Forecast:", result["forecast"])

    # Actuals vs foecasted

    comparison_df = Functions.build_forecast_vs_actual_df(results, df_estimation,columns,scaler,k=5)

    print(comparison_df.head())

    rmse = Functions.compute_rmse(comparison_df)
    print("RMSE by variable:\n", rmse)

    Functions.plot_forecast_vs_actual(comparison_df, column_index=2)


if __name__ == "__main__":
    main()