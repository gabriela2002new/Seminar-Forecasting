import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from scipy.linalg import cholesky, LinAlgError
from scipy.optimize import minimize, Bounds
from statsmodels.tsa.stattools import adfuller
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.metrics import mean_squared_error
from statsmodels.tsa.stattools import adfuller
from xarray.ufuncs import negative


# 1. Load the data
def load_data(file_path):
    df = pd.read_excel(file_path, engine='openpyxl')
    df['Months'] = pd.to_datetime(df['Months'], errors='coerce')  # in case of blanks
    df = df[~df['Months'].isna()]  # drop rows where 'Months' is blank
    df.set_index('Months', inplace=True)
    df.sort_index(inplace=True)
    return df

# 2. Filter the data
def filter_data(df, start_date, end_date, columns):
    df_filtered = df[start_date:end_date]

    return df_filtered[columns].dropna()

def random_rotation_matrix(n):
    """Generates a random orthonormal rotation matrix of size n x n"""
    random_matrix = np.random.randn(n, n)
    q, r = np.linalg.qr(random_matrix)
    # Ensure right-handed coordinate system (positive determinant)
    if np.linalg.det(q) < 0:
        q[:, 0] *= -1
    return q

# 3. Estimate the VAR model
def estimate_var_model(df_estimation, maxlags=1):
    var_model = VAR(df_estimation)
    lag_order = var_model.select_order(maxlags=maxlags)
    optimal_lag_hq = np.nanargmin(lag_order.hqic) + 1
    var_results = var_model.fit(optimal_lag_hq)
    return var_results

def estimate_ms_var_model(df_estimation, switch_date, maxlags=5):
    """
    Estimate two VAR models for different regimes based on a switching date.

    Parameters:
        df_estimation (pd.DataFrame): Time series dataframe
        switch_date (str or pd.Timestamp): The date at which the regime switches
        maxlags (int): Maximum lags to consider for lag order selection

    Returns:
        dict: Dictionary with VAR results for each regime
    """
    # Ensure datetime index
    df_estimation.index = pd.to_datetime(df_estimation.index)

    # Split into regimes
    df_pre = df_estimation[df_estimation.index < switch_date]
    df_post = df_estimation[df_estimation.index >= switch_date]

    var_models = {}
    for label, df in zip(["Regime_1", "Regime_2"], [df_pre, df_post]):
        if len(df) < maxlags + 1:
            print(f"Not enough observations in {label} for VAR estimation.")
            var_models[label] = None
            continue
        model = VAR(df)
        lag_order = model.select_order(maxlags=maxlags)
        optimal_lag = np.nanargmin(lag_order.hqic) + 1
        var_models[label] = model.fit(optimal_lag)

    return var_models

# 4. Compute covariance matrix and long-run matrix
def compute_matrices(var_results):
    residuals = var_results.resid
    cov_matrix = np.cov(residuals.T)
    A1 = np.sum(var_results.coefs, axis=0)
    C_inf = np.linalg.inv(np.eye(A1.shape[0]) - A1)
    return residuals, cov_matrix, C_inf

# 5. Optimize Cholesky matrix with sign restrictions
# Objective function to optimize Cholesky matrix with sign restrictions
import numpy as np
from scipy.optimize import minimize, Bounds
from scipy.linalg import cholesky, LinAlgError

import numpy as np
from scipy.optimize import minimize, Bounds
from scipy.linalg import LinAlgError

import numpy as np
from scipy.optimize import minimize, Bounds


import numpy as np
from scipy.optimize import minimize, Bounds

def objective(param_vec, n, cov_matrix, C_inf, restrictions, penalty_factor=1000, tolerance=1e-6):
    # Fill lower triangular part of an n x n matrix with param_vec
    L = np.zeros((n, n))
    L[np.tril_indices(n)] = param_vec

    # Compute L Lᵀ and its Frobenius norm error against the covariance matrix
    LL_T = L @ L.T
    frob_error = np.linalg.norm(LL_T - cov_matrix, 'fro')
    penalty = frob_error

    # Apply long-run restrictions
    CD = C_inf @ L
    penalty += np.linalg.norm(CD[:2, 3:], 'fro')  # zero last 2 columns in first 3 rows

    # Apply sign restrictions
    for idx, sign in restrictions.items():
        i, j = idx  # idx must be a tuple like (row, col)
        val = L[i, j]
        if sign == 'positive':
            penalty += penalty_factor * max(0, -val) ** 2
        elif sign == 'negative':
            penalty += penalty_factor * max(0, val) ** 2

    return penalty


from scipy.optimize import minimize, Bounds
import numpy as np

def optimize_matrix(cov_matrix, C_inf, restrictions):
    n = cov_matrix.shape[0]

    # Use only lower triangular elements for optimization
    initial_L = np.linalg.cholesky(cov_matrix)
    initial_vec = initial_L[np.tril_indices(n)]

    # No bounds, just a flat trust-region constrained optimization
    result = minimize(
        lambda param_vec: objective(param_vec, n, cov_matrix, C_inf, restrictions),
        initial_vec,
        method='trust-constr'
    )

    # Reconstruct full lower triangular matrix
    optimized_L = np.zeros((n, n))
    optimized_L[np.tril_indices(n)] = result.x

    return optimized_L



# 6. Compute structural shocks
def compute_structural_shocks(residuals, optimized_matrix):
    return np.dot(residuals, np.linalg.inv(optimized_matrix).T)

#---------------------------------------------------------------------------------------------------------------------------------
#Sign restrictions for the three scenarios:demand, demand+supply, (large) demand +supply
#--------------------------------------------------------------------------------------------------------------------------------

#1.Define named sign restrictions for supply+demand(baseline)

def define_named_sign_restrictions():
    return {
        # Shock source → { variable affected: sign }
        # Shock source → { variable affected: sign }
        'Brent_logdiff': {
            'Brent_logdiff': 'positive',
            'Gas Prices_logdiff': 'positive',
            'growth_rate_inflation': 'positive',
        },
        'Gas Prices_logdiff': {
            'Gas Prices_logdiff': 'positive',
            'growth_rate_inflation': 'positive',
        },
        'EUR-USD_logdiff': {
            'EUR-USD_logdiff': 'positive',

        },
        'growth_rate_inflation': {
            'growth_rate_inflation': 'positive',
            'DSPIC96_log_diff': 'positive',
        },
        'DSPIC96_log_diff': {
            'DSPIC96_log_diff': 'positive',
        }
    }


#2.Define sign restrictions for demand model()
def define_named_sign_restrictions_demand():
    return {
        'EUR-USD_logdiff': {
        'EUR-USD_logdiff': 'positive',
    },
    'growth_rate_inflation': {
        'growth_rate_inflation': 'positive',
        'DSPIC96_log_diff': 'positive',
    },
    'DSPIC96_log_diff': {
        'DSPIC96_log_diff': 'positive',
    }
    }

#3.Define sign restrictions for demand+supply(large model)

def define_named_sign_restrictions_large():
    return {
        # Shock source → { variable affected: sign }
        # Shock source → { variable affected: sign }
        'Brent_logdiff': {
            'Brent_logdiff': 'positive',
            'Gas Prices_logdiff': 'positive',
            'growth_rate_inflation': 'positive',
        },
        'Gas Prices_logdiff': {
            'Gas Prices_logdiff': 'positive',
            'growth_rate_inflation': 'positive',
        },
        'growth_rate_inflation': {
            'growth_rate_inflation': 'positive',
            'DSPIC96_log_diff': 'positive',

            'InterestDiff': 'positive'
        },
        'GECON index': {
            'GECON index': 'positive'

        },
        'InterestDiff': {
            'InterestDiff': 'positive'

        },
        'DSPIC96_log_diff': {
            'DSPIC96_log_diff': 'positive',
        },
        'EUR-USD_logdiff': {
            'EUR-USD_logdiff': 'positive',

        },

    }


def convert_named_to_index_restrictions(named_restrictions, columns):
    index_restrictions = {}
    for shock_var, effects in named_restrictions.items():
        shock_idx = columns.index(shock_var)
        for affected_var, sign in effects.items():
            affected_idx = columns.index(affected_var)
            index_restrictions[(affected_idx, shock_idx)] = sign
    return index_restrictions


#8.Compute IRF s for a set of columns against a main variable

def compute_side_IRF(columns, num_periods, shock_indices,structural_shocks, main_index):
    side_irfs = np.zeros((num_periods, len(columns)))  # For inflation responses to supply-side shocks
    for j in shock_indices:
        for t in range(num_periods):
            side_irfs[t, j] = np.sum(structural_shocks[:t + 1, main_index] * structural_shocks[:t + 1, j])
    return side_irfs


#9.Plot the IRFs
def plot_side_shocks(shock_indices,columns,side_irfs):
    # Plot supply-side shocks (Brent, Gas Prices)
    fig, ax = plt.subplots(figsize=(10, 6))
    for j in shock_indices:
        ax.plot(side_irfs[:, j], label=f'Response of Inflation to Shock {columns[j]}')
    ax.set_title('Impulse Responses of Inflation to Supply-Side Shocks')
    ax.set_xlabel('Periods')
    ax.set_ylabel('Response')
    ax.legend()
    plt.tight_layout()
    plt.show()

#10.Compute irfs for each variable to each structural shock

def compute_IRF(columns, num_periods,structural_shocks):
    structural_irfs = np.zeros((num_periods, len(columns), len(columns)))
    for i in range(len(columns)):
        for j in range(len(columns)):
            for t in range(num_periods):
                # Each response is just the cumulative sum of the responses to the structural shocks
                structural_irfs[t, i, j] = np.sum(structural_shocks[:t + 1, i] * structural_shocks[:t + 1, j])
    return structural_irfs

#11.Compute the cumulative irfs by summing all irfs from a specific chosen set against inflation
def augmented_IRFS(num_periods,structural_irfs,main_index,side_indices):
    irfs_per_period = []

    # Loop over each time period (horizon)
    for t in range(num_periods):  # Loop over the specified number of periods
        # Sum the responses of inflation (inflation_index) to all the cost-push shocks (Brent, Gas Prices, GSCPI)
        irfs_at_t = np.sum(
            structural_irfs[t, main_index, side_indices])  # Sum for the given period t
        irfs_per_period.append(irfs_at_t)  # Store the result for this period

    # Convert the list to a numpy array
    irfs_per_period = np.array(irfs_per_period)
    return irfs_per_period

#12.Plotting the cumulative irfs

def plot_augumented_IRFS(irfs_per_period,label,title):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(irfs_per_period, label=label)
    ax.set_title(title)
    ax.set_xlabel('Periods')
    ax.set_ylabel('Response')
    ax.legend()
    plt.tight_layout()
    plt.show()

#13.Compute FEVD

def compute_FEVD(num_periods, columns, structural_irfs, main_index):
    # Initialize arrays to store FEVD for inflation at each time period
    fevd_inflation = np.zeros((num_periods, len(columns)))

    # Calculate FEVD for inflation for each time period
    for t in range(num_periods):
        total_variance = np.sum(structural_irfs[t, main_index, :] ** 2)  # Total variance of inflation at time t
        for j in range(len(columns)):
            fevd_inflation[t, j] = np.sum(
                structural_irfs[t, main_index, j] ** 2) / total_variance  # Contribution from each shock
    return fevd_inflation

def compute_generalized_FEVD(num_periods, columns, structural_irfs, main_index):
    fevd_inflation = np.zeros((num_periods, len(columns)))

    for t in range(num_periods):
        total = 0.0
        for j in range(len(columns)):
            fevd_inflation[t, j] = structural_irfs[t, main_index, j] ** 2
            total += fevd_inflation[t, j]
        fevd_inflation[t, :] /= total if total > 0 else 1.0  # Avoid division by zero
    return fevd_inflation


#14.PLot FEVD

def plot_FEVD(columns, fevd_inflation):
    fig, ax = plt.subplots(figsize=(10, 6))

    # Plot FEVD for each shock (e.g., Brent, Gas Prices, etc.)
    for j in range(len(columns)):
        ax.plot(fevd_inflation[:, j], label=f'Contribution of {columns[j]} Shock')

    ax.set_title('Forecast Error Variance Decomposition (FEVD) for Inflation')
    ax.set_xlabel('Periods')
    ax.set_ylabel('Contribution to Variance')
    ax.legend()
    plt.tight_layout()
    plt.show()

#14. Forecast Inflation
def forecast_inflation_using_historical_shocks(residuals, structural_irfs, inflation_index, num_periods):
    """
    Forecast inflation by applying the historical shocks to the structural IRFs.

    Parameters:
    residuals (numpy array): The residuals from the VAR model that represent historical shocks.
    structural_irfs (numpy array): The impulse response functions for the structural shocks.
    inflation_index (int): The index corresponding to inflation in the dataset.
    num_periods (int): The number of periods to forecast.

    Returns:
    forecasted_inflation (numpy array): The forecasted inflation values over the forecast horizon.
    """
    # Initialize an array to store the forecasted inflation for each period
    forecasted_inflation = np.zeros(num_periods)

    # Loop over each period and apply the shocks
    for period in range(num_periods):
        # Initialize the total shock impact on inflation for this period
        total_inflation_impact = 0

        # Loop over the residuals (historical shocks) and apply them to the corresponding IRFs
        for shock_index in range(residuals.shape[0]):  # Loop over each shock (e.g., Brent, GDP, etc.)
            # Apply the historical shock to the IRF of the corresponding variable on inflation
            total_inflation_impact += structural_irfs[shock_index, inflation_index, period] * residuals[
                shock_index, period]

        # Store the total impact on inflation for this period
        forecasted_inflation[period] = total_inflation_impact

    return forecasted_inflation
#15. Plot the forecasted inflation

def plot_forecasted_inflation(forecasted_inflation, title="Forecasted Inflation"):
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(forecasted_inflation)), forecasted_inflation, label="Forecasted Inflation")
    plt.title(title)
    plt.xlabel("Periods")
    plt.ylabel("Inflation (%)")
    plt.grid(True)
    plt.legend()
    plt.show()

#16.Check for stationarity

from statsmodels.tsa.stattools import adfuller
import pandas as pd

def test_stationarity(df, columns, significance_level=0.05):
    """
    Tests whether multiple time series in a DataFrame are stationary using the Augmented Dickey-Fuller test.

    Parameters:
    df (pd.DataFrame): The DataFrame containing time series.
    columns (list): List of column names to test.
    significance_level (float): The significance level to test the p-value (default is 0.05).

    Returns:
    dict: Dictionary of results per column with test statistic, p-value, critical values, and conclusion.
    """
    all_results = {}

    for col in columns:
        print(f"\n=== Testing Stationarity for Column: {col} ===")
        series = df[col].dropna()

        result = adfuller(series)
        test_statistic = result[0]
        p_value = result[1]
        critical_values = result[4]

        if p_value <= significance_level:
            conclusion = "The series is stationary (reject null hypothesis)."
        else:
            conclusion = "The series is non-stationary (fail to reject null hypothesis)."

        print(f"Test Statistic: {test_statistic}")
        print(f"p-value: {p_value}")
        print("Critical Values:")
        for key, value in critical_values.items():
            print(f"    {key}: {value}")
        print(f"Conclusion: {conclusion}")

        all_results[col] = {
            'Test Statistic': test_statistic,
            'p-value': p_value,
            'Critical Values': critical_values,
            'Conclusion': conclusion
        }

    return all_results

    return result_dict

#17.Scale the data



def scale_columns(df: pd.DataFrame, columns: list) -> tuple[pd.DataFrame, StandardScaler]:
    """
    Scales the specified columns using StandardScaler and returns the scaler for inverse_transform.
    """
    scaler = StandardScaler()
    df_scaled = df.copy()
    df_scaled[columns] = scaler.fit_transform(df[columns])
    return df_scaled, scaler


def unscale_columns(df_scaled: pd.DataFrame, columns: list, scaler: StandardScaler) -> pd.DataFrame:
    """
    Unscales the specified columns using the provided scaler.
    """
    df_unscaled = df_scaled.copy()
    df_unscaled[columns] = scaler.inverse_transform(df_scaled[columns])
    return df_unscaled

#18.Forecast Values

def forecast_var(var_results, df_estimation, steps=10):
    """
    Forecast future values using the VAR model.

    Parameters:
    var_results: The result of the fitted VAR model.
    df_estimation: DataFrame containing the historical data to base the forecast on.
    steps: The number of periods ahead to forecast.

    Returns:
    forecast: DataFrame with the forecasted values.
    """
    # Get the last `lags` observations from the dataset
    lag_order = var_results.k_ar
    last_obs = df_estimation.iloc[-lag_order:]

    # Forecast the next `steps` periods
    forecast = var_results.forecast(last_obs.values, steps=steps)

    # Create a DataFrame for the forecasted values
    forecast_index = pd.date_range(start=df_estimation.index[-1] + pd.DateOffset(months=1), periods=steps, freq='MS')
    forecast_df = pd.DataFrame(forecast, columns=df_estimation.columns, index=forecast_index)
    return forecast_df

#19.Plot the forecast

import matplotlib.pyplot as plt
import pandas as pd

def plot_forecast(forecast_df, df_actual, inflation_column, forecast_steps):
    """
    Plots the forecasted inflation against actual inflation values over the same forecast period.

    Parameters:
    - forecast_df: DataFrame containing forecasted values
    - df_actual: DataFrame with actual future values of inflation (same period as forecast)
    - inflation_column: The column name for inflation in both DataFrames
    - forecast_steps: Number of steps forecasted
    """

    # Ensure the index is datetime
    forecast_df.index = pd.to_datetime(forecast_df.index)
    df_actual.index = pd.to_datetime(df_actual.index)

    # Limit both to forecast steps and align
    forecast_series = forecast_df[inflation_column].iloc[:forecast_steps]
    actual_series = df_actual[inflation_column].iloc[:forecast_steps]

    # Make sure they align by index (assumed both are from same starting point)
    common_index = actual_series.index.intersection(forecast_series.index)

    # Plot
    plt.figure(figsize=(12, 6))
    plt.plot(common_index, actual_series.loc[common_index], label='Actual Inflation', marker='o')
    plt.plot(common_index, forecast_series.loc[common_index], label='Forecasted Inflation', linestyle='--', marker='x')
    plt.title('Forecasted vs Actual Inflation (Same Period)')
    plt.xlabel('Date')
    plt.ylabel('Inflation (scaled/log diff)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


#20.Compute the forecast MSE
def compute_forecast_mse(forecast_df, df_actual, inflation_column, max_forecast_steps):
    """
    Computes the Mean Squared Error between forecasted and actual inflation for each forecast horizon.

    Parameters:
    - forecast_df: DataFrame containing forecasted values
    - df_actual: DataFrame with actual future values of inflation
    - inflation_column: Column name for inflation
    - max_forecast_steps: Maximum number of steps to forecast

    Returns:
    - mse_list: List of Mean Squared Errors for each forecast horizon
    """

    mse_list = []

    for forecast_steps in range(1, max_forecast_steps + 1):
        # Align and limit to the forecast horizon
        forecast_series = forecast_df[inflation_column].iloc[:forecast_steps]
        actual_series = df_actual[inflation_column].iloc[:forecast_steps]

        # Align by index just to be safe
        common_index = actual_series.index.intersection(forecast_series.index)

        # Compute MSE
        mse = mean_squared_error(actual_series.loc[common_index], forecast_series.loc[common_index])
        mse_list.append(mse)

    return mse_list

#21.Define sign restrictions for demand model
def define_named_sign_restrictions_supply():
    return {
        # Shock source → { variable affected: sign }
        'Brent_logdiff': {
            'Brent_logdiff': 'positive',
            'Gas Prices_logdiff': 'positive',
            'acceleration_inflation': 'positive',
        },
        'Gas Prices_logdiff': {
            'Gas Prices_logdiff': 'positive',
            'acceleration_inflation': 'positive',
        }

    }



#23. Objective function to optimize Cholesky matrix with sign restrictions
def objective_demand(chol_vec, n, cov_matrix, C_inf, restrictions, penalty_factor=1000):
    L = np.zeros((n, n))
    L[np.tril_indices(n)] = chol_vec  # Fill lower triangular matrix
    LL_T = L @ L.T  # Compute L L^T

    # Apply long-run restriction penalty
    penalty = np.linalg.norm(LL_T - cov_matrix, 'fro')

    # Enforce long-run restriction: set last two columns of first 4 rows of C_inf D to zero
    CD = C_inf @ L
    # Set last two columns (4th and 5th) of the first 3 rows to zero
    penalty += np.linalg.norm(CD[:1, 1:], 'fro')  # This ensures that the last 2 columns in the first 3 rows are zero

    # Apply sign restrictions with stronger penalty
    for idx, sign in restrictions.items():
        if sign == 'positive':
            penalty += penalty_factor * max(0, -L[idx]) ** 2  # Penalize large if negative
        elif sign == 'negative':
            penalty += penalty_factor * max(0, L[idx]) ** 2  # Penalize large if positive

    return penalty
#24.  Optimize Cholesky matrix with sign restrictions

def optimize_chol_matrix_demand(cov_matrix, C_inf, restrictions):
    n = cov_matrix.shape[0]

    # Ensure positive definiteness
    try:
        chol_matrix = cholesky(cov_matrix, lower=True)
    except LinAlgError:
        raise ValueError("Covariance matrix is not positive definite.")

    # Flatten lower triangular part
    chol_vec = chol_matrix[np.tril_indices(n)]

    # Optimize with constraints
    result = minimize(lambda chol_vec: objective(chol_vec, n, cov_matrix, C_inf, restrictions),
                      chol_vec, method='trust-constr', bounds=Bounds(*zip(*[(-np.inf, np.inf)] * len(chol_vec))))

    # Construct optimized Cholesky matrix
    optimized_chol_matrix = np.zeros((n, n))
    optimized_chol_matrix[np.tril_indices(n)] = result.x

    return optimized_chol_matrix

def adf_test(series, title=''):
    print(f'ADF Test: {title}')
    result = adfuller(series.dropna())
    labels = ['ADF Statistic', 'p-value', '# Lags Used', '# Observations']
    for value, label in zip(result[:4], labels):
        print(f'{label} : {value}')
    if result[1] <= 0.05:
        print("✅ Stationary")
    else:
        print("❌ Non-stationary")


def rolling_svar_forecast3(data, window_size, lags, steps_ahead=1):
    """
    Run rolling window SVAR estimation and compute N-step-ahead forecasts.

    Parameters:
    -----------
    data : pd.DataFrame
        Time series data.
    window_size : int
        Size of rolling window.
    lags : int
        Number of lags in the VAR.
    steps_ahead : int
        Number of steps ahead to forecast.
    A : np.ndarray or None
        Short-run restriction matrix A (use np.nan for free parameters).
    B : np.ndarray or None
        Short-run restriction matrix B (optional).

    Returns:
    --------
    results_list : list of dict
        Each dict contains 'svar_model': fitted SVARResults and
        'forecast': N-step-ahead forecast as a NumPy array.
    """
    from statsmodels.tsa.api import VAR

    results_list = []
    n_obs = data.shape[0]

    for start in range(n_obs - window_size - steps_ahead + 1):
        end = start + window_size
        window_data = data.iloc[start:end]

        try:
            model = VAR(window_data)
            var_res = model.fit(lags)

            # Get the last `lags` observations to use for forecasting
            last_obs = window_data.values[-lags:]

            # Forecast N steps ahead
            forecast = var_res.forecast(last_obs, steps=steps_ahead)

            # Take only the N-th step forecast (e.g., step 3 of 3-step forecast)
            nth_forecast = forecast[steps_ahead - 1]

            results_list.append({
                "svar_model": var_res,
                "forecast": nth_forecast,
                "start_index": start,
                "end_index": end,
                "forecast_step_index": end + steps_ahead - 1
            })
        except Exception as e:
            print(f"Window {start}-{end} failed: {e}")
            results_list.append(None)

    return results_list



#----------------------------------------------------------------------------------------------------------
#Rolling window forecasting +RMSE+plotting
#------------------------------------------------------------------------------------------------------------------------



def rolling_svar_forecast(data, window_size, lags,steps_ahead=1):
    """
    Run rolling window SVAR estimation and compute 1-step-ahead forecasts.

    Parameters:
    -----------
    data : pd.DataFrame
        Time series data.
    window_size : int
        Size of rolling window.
    lags : int
        Number of lags in the VAR.
    A : np.ndarray or None
        Short-run restriction matrix A (use np.nan for free parameters).
    B : np.ndarray or None
        Short-run restriction matrix B (optional).

    Returns:
    --------
    results_list : list of dict
        Each dict contains 'svar_model': fitted SVARResults and
        'forecast': 1-step-ahead forecast as a NumPy array.
    """

    results_list = []
    n_obs = data.shape[0]

    for start in range(n_obs - window_size-steps_ahead + 1):
        end = start + window_size
        window_data = data.iloc[start:end]

        try:
            model = VAR(window_data)
            var_res = model.fit(lags)



            # Get the last `lags` observations to use for forecasting
            last_obs = window_data.values[-lags:]

            # Forecast one period ahead
            forecast = var_res.forecast(last_obs, steps=steps_ahead)
            nth_forecast=forecast[steps_ahead-1]

            results_list.append({
                "svar_model": var_res,
                "forecast": nth_forecast,  # [0] to get the 1D array for the 1-step
                "start_index": start,
                "end_index": end,
                "forecast_step_index":end+steps_ahead-1
            })
        except Exception as e:
            print(f"Window {start}-{end} failed: {e}")
            results_list.append(None)

    return results_list



def build_forecast_vs_actual_df(results_list, original_data, columns, scaler, k=5):
    forecasts = []
    actuals = []
    indices = []

    for result in results_list:
        if result is None:
            forecasts.append([np.nan] * original_data.shape[1])
            actuals.append([np.nan] * original_data.shape[1])
            indices.append(None)
        else:
            end_index = result["end_index"]
            if end_index >= len(original_data):
                continue
            forecasts.append(result["forecast"])
            actuals.append(original_data.iloc[end_index].values)
            indices.append(original_data.index[end_index])

    valid = [i for i in range(len(indices)) if indices[i] is not None]

    actuals = [actuals[i] for i in valid]
    forecasts = [forecasts[i] for i in valid]
    indices = [indices[i] for i in valid]

    # Convert to DataFrames
    actuals_df = pd.DataFrame(actuals, columns=columns)
    forecasts_df = pd.DataFrame(forecasts, columns=columns)

    # Unscale
    actuals_df = unscale_columns(actuals_df, columns, scaler)
    forecasts_df = unscale_columns(forecasts_df, columns, scaler)

    # Set indices for alignment
    actuals_df.index = indices
    forecasts_df.index = indices

    df_comparison = pd.concat(
        {"forecast": forecasts_df, "actual": actuals_df},
        axis=1
    )

    return df_comparison

def compute_rmse(comparison_df):
    """
    Compute RMSE between forecast and actual values for each variable.

    Parameters:
    -----------
    comparison_df : pd.DataFrame
        DataFrame with multi-level columns ('forecast', var) and ('actual', var).

    Returns:
    --------
    rmse_series : pd.Series
        RMSE for each variable.
    """
    import numpy as np

    forecast = comparison_df["forecast"]
    actual = comparison_df["actual"]

    mse = ((forecast - actual) ** 2).mean()
    rmse = np.sqrt(mse)

    return rmse

def plot_forecast_vs_actual(comparison_df, column_index=2):
    """
    Plot actual vs forecasted values for a specific column index.

    Parameters:
    -----------
    comparison_df : pd.DataFrame
        Output from build_forecast_vs_actual_df with multi-index columns.
    column_index : int
        Index of the variable/column to plot (0-based).
    """
    variable = comparison_df['actual'].columns[column_index]

    plt.figure(figsize=(12, 6))
    plt.plot(comparison_df.index, comparison_df['actual'][variable], label='Actual', color='black')
    plt.plot(comparison_df.index, comparison_df['forecast'][variable], label='Forecast', color='dodgerblue', linestyle='--')

    plt.title(f'Actual vs Forecasted: {variable}')
    plt.xlabel('Date')
    plt.ylabel(variable)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()