import numpy as np
import pandas as pd
from scipy.stats import invwishart, multivariate_normal
from numpy.linalg import inv, cholesky
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error


def load_data(file_path, columns):
    df = pd.read_excel(file_path, engine='openpyxl')
    df['Months'] = pd.to_datetime(df['Months'])
    df.set_index('Months', inplace=True)
    df = df[columns].dropna()
    return df.to_numpy(), df


# 2. Filter the data
def filter_data(df, start_date, end_date, columns):
    df_filtered = df[start_date:end_date]
    return df_filtered[columns].dropna()


def prepare_data(data, p):
    Y = data[p:]
    X = np.hstack([data[p - lag - 1:-lag - 1] for lag in range(p)])
    # Removed the line that adds a constant term to X
    return Y, X


def set_minnesota_priors(data, k, p, lambda_1=0.2, lambda_2=0.5, lambda_3=100):
    sigma_sq = np.var(data, axis=0)
    B_prior = np.zeros((k, k * p))  # Adjusted the shape of B_prior (no intercept)
    V_prior = np.zeros((k, k * p))  # Adjusted the shape of V_prior (no intercept)
    for i in range(k):
        for j in range(k * p):
            var_idx = j % k
            lag = j // k + 1
            if i == var_idx:
                V_prior[i, j] = (lambda_1 / lag ** 2)
            else:
                V_prior[i, j] = (lambda_2 * sigma_sq[i]) / (lag ** 2 * sigma_sq[var_idx])
    return B_prior, V_prior


def run_mcmc(Y, X, B_prior, V_prior, k, p, irf_horizon, sign_restrictions,
             Psi_0=None, nu_0=None, n_draws=1000, burn_in=200, seed=42):
    """
    Run MCMC sampling for Bayesian SVAR with explicit inverse-Wishart prior on D^{-1}.
    """
    T = Y.shape[0]
    if nu_0 is None:
        nu_0 = k + 1
    if Psi_0 is None:
        Psi_0 = np.eye(k)

    np.random.seed(seed)
    B_draws = np.zeros((n_draws - burn_in, k, k * p))  # Adjusted shape (no intercept)
    Sigma_draws = np.zeros((n_draws - burn_in, k, k))
    D_draws = np.zeros((n_draws - burn_in, k, k))
    irfs = np.zeros((n_draws - burn_in, irf_horizon, k, k))
    fevd = np.zeros((n_draws - burn_in, irf_horizon, k, k))

    draw_count = 0
    draw = 0
    XTX, XTY = X.T @ X, X.T @ Y

    while draw_count < n_draws:
        # ----- Sample B conditional on Sigma -----
        B_post = np.zeros_like(B_prior)
        for i in range(k):
            V_prior_inv = np.diag(1 / V_prior[i])
            V_post_i = inv(XTX + V_prior_inv)
            M_post_i = V_post_i @ XTY[:, i]
            B_post[i] = multivariate_normal.rvs(mean=M_post_i, cov=V_post_i)

        # Residuals
        E = Y - X @ B_post.T

        # Posterior update for D^{-1} ~ IW(Psi_0 + E'E, nu_0 + T)
        Psi_post = Psi_0 + E.T @ E
        nu_post = nu_0 + T
        D_inv = invwishart.rvs(df=nu_post, scale=Psi_post)
        D = inv(D_inv)  # D is the structural matrix
        Sigma_draw = D @ D.T  # implied Sigma

        # Companion form for IRFs
        B_compact = B_post[:, :].reshape(k, p, k).transpose(1, 0, 2)
        A = np.zeros((k * p, k * p))
        A[:k] = np.hstack(B_compact)
        A[k:, :-k] = np.eye(k * (p - 1))

        # ----- Apply sign restrictions to D via rotation -----
        accepted = False
        max_attempts = 100
        for _ in range(max_attempts):
            Q, _ = np.linalg.qr(np.random.randn(k, k))  # random orthogonal matrix
            D_rot = D @ Q

            # Compute IRFs
            C = np.zeros((irf_horizon, k, k))
            C[0] = D_rot
            for h in range(1, irf_horizon):
                C[h] = A[:k, :k] @ C[h - 1]

            # Apply sign restrictions
            if all(sign_restrictions[j] * C[0, sign_restrictions['target'], j] > 0 for j in range(k)):
                accepted = True
                break

        if not accepted:
            continue  # reject draw and continue loop

        # ----- Save draws if past burn-in -----
        if draw >= burn_in:
            idx = draw - burn_in
            B_draws[idx] = B_post
            Sigma_draws[idx] = Sigma_draw
            D_draws[idx] = D_rot
            irfs[idx] = C

            for h in range(irf_horizon):
                for i in range(k):
                    total_var = np.sum([np.sum(C[:h + 1, i, j] ** 2) for j in range(k)])
                    for j in range(k):
                        contrib = np.sum(C[:h + 1, i, j] ** 2)
                        fevd[idx, h, i, j] = contrib / total_var if total_var > 0 else 0.0

        draw += 1
        draw_count += 1

    return B_draws, Sigma_draws, D_draws, irfs, fevd


def summarize_posteriors(B, Sigma, P, irfs, fevd, columns, p):
    k = len(columns)
    mean_B = B.mean(axis=0)
    mean_Sigma = Sigma.mean(axis=0)
    mean_P = P.mean(axis=0)
    lower_B = np.percentile(B, 2.5, axis=0)
    upper_B = np.percentile(B, 97.5, axis=0)
    print("\n--- 95% Credible Intervals for B ---")
    for i in range(k):
        print(f"\nEquation for {columns[i]}:")
        for j in range(k * p):
            lb, ub = lower_B[i, j], upper_B[i, j]
            sig = "SIGNIFICANT" if lb * ub > 0 else "not significant"
            print(f"  Coef {j:2d}: [{lb:.4f}, {ub:.4f}] → {sig}")
    return mean_B, mean_Sigma, mean_P, irfs.mean(axis=0), fevd.mean(axis=0)


def plot_irfs(irfs, lower_irfs, upper_irfs, inflation_idx, k, columns):
    plt.figure(figsize=(10, 6))
    for j in range(k):
        plt.plot(irfs[:, inflation_idx, j], label=f"{columns[j]} shock")
        plt.fill_between(range(len(irfs)), lower_irfs[:, inflation_idx, j], upper_irfs[:, inflation_idx, j], alpha=0.2)
    plt.title("Inflation Response to Structural Shocks")
    plt.xlabel("Horizon")
    plt.ylabel("Response")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def plot_fevd(fevd, lower_fevd, upper_fevd, inflation_idx, k, columns):
    plt.figure(figsize=(10, 6))
    for j in range(k):
        plt.plot(fevd[:, inflation_idx, j], label=f"{columns[j]} shock")
        plt.fill_between(range(len(fevd)), lower_fevd[:, inflation_idx, j], upper_fevd[:, inflation_idx, j], alpha=0.2)
    plt.title("FEVD: Inflation Forecast Variance Explained by Each Shock")
    plt.xlabel("Horizon")
    plt.ylabel("Variance Contribution")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def scale_columns(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    scaler = StandardScaler()
    df_scaled = df.copy()
    df_scaled[columns] = scaler.fit_transform(df[columns])
    return df_scaled


import numpy as np

def compute_and_print_credible_intervals(B_draws, Sigma_draws, P_draws):
    def get_credible_interval(draws, name):
        lower = np.percentile(draws, 2.5, axis=0)
        upper = np.percentile(draws, 97.5, axis=0)
        print(f"\nCredible Interval for {name} (2.5% - 97.5% percentiles):")
        print("Lower Bound:\n", lower)
        print("Upper Bound:\n", upper)
        return lower, upper

    lower_B, upper_B = get_credible_interval(B_draws, "B")
    lower_Sigma, upper_Sigma = get_credible_interval(Sigma_draws, "Sigma")
    lower_P, upper_P = get_credible_interval(P_draws, "P")

    return {
        'B': (lower_B, upper_B),
        'Sigma': (lower_Sigma, upper_Sigma),
        'P': (lower_P, upper_P)
    }


def rolling_svar_forecast_bayesian_steps(
    data, window_size, steps_ahead=1, irf_horizon=15,
    num_draws=500, p=1, columns=None
):
    """
    Run rolling window Bayesian SVAR estimation and forecast using MCMC posterior draws.

    Parameters:
    -----------
    data : pd.DataFrame
        Scaled and filtered time series data.
    window_size : int
        Size of rolling window.
    steps_ahead : int
        Forecast horizon (final step returned).
    irf_horizon : int
        Horizon for impulse response estimation.
    num_draws : int
        Number of MCMC samples.
    p : int
        Lag order.
    columns : list
        List of column names in the correct order.

    Returns:
    --------
    results_list : list of dict
        Each dict contains forecast results and metadata for that window.
    """
    results_list = []
    n_obs = data.shape[0]
    k = data.shape[1]

    inflation_idx = columns.index("growth_rate_inflation")

    for start in range(n_obs - window_size + 1 - steps_ahead):
        end = start + window_size
        window_df = data.iloc[start:end]

        try:
            # Prepare data
            Y, X = prepare_data(window_df.to_numpy(), p)
            B_prior, V_prior = set_minnesota_priors(window_df.to_numpy(), k, p)

            # Sign restrictions setup
            sign_restrictions = np.ones(k)
            sign_restrictions[inflation_idx] = 1
            sign_restrictions = {
                'target': inflation_idx,
                **dict(enumerate(sign_restrictions))
            }

            # Run MCMC
            B_draws, Sigma_draws, P_draws, irfs, fevd = run_mcmc(
                Y, X, B_prior, V_prior, k, p, irf_horizon, sign_restrictions
            )

            # Prepare last observations for forecasting
            last_obs = window_df.iloc[-p:].to_numpy()
            forecast_input = last_obs.flatten()[::-1][:k * p]

            # Multi-step forecasting: only keep the final step
            forecast_draws = []
            for b in B_draws:
                b_matrix = b.reshape((k, k * p))
                current_input = forecast_input.copy()

                for _ in range(steps_ahead):
                    next_forecast = np.dot(b_matrix, current_input[:k * p])
                    current_input = np.concatenate([next_forecast, current_input])[:k * p]

                forecast_draws.append(next_forecast)  # Only keep last step

            forecast_draws = np.array(forecast_draws)  # shape: (num_draws, k)
            forecast_mean = forecast_draws.mean(axis=0)

            # Store results
            results_list.append({
                "forecast_draws": forecast_draws,          # Shape: (num_draws, k)
                "forecast": forecast_mean,                 # Shape: (k,)
                "start_index": start,
                "end_index": end,
                "forecast_step_index": end + steps_ahead - 1,
            })

            print(f"Window {start}-{end}: Forecast at t+{steps_ahead} = {forecast_mean}")

        except Exception as e:
            print(f"Rolling window {start}-{end} failed: {e}")
            results_list.append(None)

    return results_list

def plot_forecasts_with_ci(results_list, actual_data, target_column, var_index):
    forecast_means = []
    forecast_lowers = []
    forecast_uppers = []
    actuals = []
    dates = []

    for res in results_list:
        if res is not None:
            idx = res["forecast_step_index"]
            if idx < len(actual_data):
                forecast_mean = res["forecast"][var_index]
                forecast_draws = res["forecast_draws"][:, var_index]

                lower = np.percentile(forecast_draws, 2.5)
                upper = np.percentile(forecast_draws, 97.5)

                forecast_means.append(forecast_mean)
                forecast_lowers.append(lower)
                forecast_uppers.append(upper)

                if isinstance(target_column, int):
                    actual_val = actual_data.iloc[idx, target_column]
                else:
                    actual_val = actual_data.iloc[idx][target_column]

                actuals.append(actual_val)
                dates.append(actual_data.index[idx])

    # Plotting
    plt.figure(figsize=(12, 6))
    plt.plot(dates, actuals, label="Actual", color="black")
    plt.plot(dates, forecast_means, label="Forecast", color="blue")
    plt.fill_between(dates, forecast_lowers, forecast_uppers, color="blue", alpha=0.3, label="95% CI")
    plt.title(f"Forecast vs Actual - Variable {target_column}")
    plt.xlabel("Time")
    plt.ylabel("Value")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()



def compute_rmse_rolling(results_list, actual_data, target_column):
    """
    Compute RMSE of the forecasts against actual data for a specific column.

    Parameters:
    -----------
    results_list : list
        Output from rolling_svar_forecast_bayesian_steps.
    actual_data : pd.DataFrame
        Original time series data.
    target_column : int or str
        Index or name of the column to compute RMSE for.

    Returns:
    --------
    rmse : float
        Root Mean Squared Error.
    """
    forecasts = []
    actuals = []

    for res in results_list:
        if res is not None:
            forecast_idx = res["forecast_step_index"]
            if forecast_idx < len(actual_data):
                forecast_array = res["forecast"]  # shape: (n_vars,)

                if isinstance(target_column, int):
                    forecast_val = forecast_array[target_column]
                    actual_val = actual_data.iloc[forecast_idx, target_column]
                else:
                    col_idx = actual_data.columns.get_loc(target_column)
                    forecast_val = forecast_array[col_idx]
                    actual_val = actual_data.iloc[forecast_idx][target_column]

                forecasts.append(forecast_val)
                actuals.append(actual_val)

    mse = mean_squared_error(actuals, forecasts)
    rmse = np.sqrt(mse)

    return rmse


import os

def save_results_to_file(summary, forecasted_values, rmse,mean_forecast,lower_forecast,upper_forecast, output_path='output_results.txt'):
    with open(output_path, 'w') as f:
        f.write("==== Summary of Trace ====\n")
        f.write(summary.to_string())  # az.summary returns a DataFrame
        f.write("\n\n==== Forecasted Values (Inflation) ====\n")
        f.write(str(forecasted_values[:, 2]))  # Assuming response_idx=2
        f.write("\n\n==== RMSE ====\n")
        f.write(str(rmse))
        f.write("\n\n==== mean_forecast ====\n")
        f.write(str(mean_forecast))
        f.write("\n\n==== lower_forecast(2.5) ====\n")
        f.write(str(lower_forecast))
        f.write("\n\n==== upper_forecast(97.5) ====\n")
        f.write(str(upper_forecast))
    print(f"\nResults saved to: {os.path.abspath(output_path)}")


