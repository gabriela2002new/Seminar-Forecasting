# === Importing Libraries ===
import numpy as np
import pymc as pm
import arviz as az
import matplotlib.pyplot as plt
import pandas as pd
import pytensor.tensor as tt
from numpy.array_api import positive
from numpy.ma.core import negative
from sklearn.preprocessing import StandardScaler

import BSVAR_functions


def main():

        print("Starting main()...")

        # === Configuration ===
        columns = [
            'growth_rate_inflation',
            'DSPIC96_log_diff',
            'EUR-USD_logdiff',
        ]
        file_path = r'C:\Users\acer\PycharmProjects\PreprocessingOfData\Stationary_data_mine (15).xlsx'
        p = 1
        irf_horizon = 15
        start_date = '2015-01'
        end_date = '2024-01'

        # === Load and Preprocess Data ===
        print("Loading data...")
        data, df = BSVAR_functions.load_data(file_path,columns)
        print("Data loaded.")

        print("Filtering and scaling data...")
        filtered_df = BSVAR_functions.filter_data(df, start_date, end_date, columns)
        filtered_df = BSVAR_functions.scale_columns(filtered_df, columns)
        print("Filtered data shape:", filtered_df.shape)

        # === Prepare Data for Modeling ===
        data_array = filtered_df.values.astype(np.float64)
        n_vars = data_array.shape[1]
        k = len(columns)

        Y, X = BSVAR_functions.prepare_data(filtered_df.to_numpy(), p)
        B_prior, V_prior = BSVAR_functions.set_minnesota_priors(filtered_df.to_numpy(), k, p)
        inflation_idx = columns.index("growth_rate_inflation")

        # === Define Sign Restrictions ===
        sign_restrictions = np.ones(k)
        sign_restrictions[inflation_idx] = 1  # Inflation responds positively to its own shock
        sign_restrictions = {
            'target': inflation_idx,
            **dict(enumerate(sign_restrictions))
        }

        # === MCMC Sampling ===
        B_draws, Sigma_draws, P_draws, irfs, fevd = BSVAR_functions.run_mcmc(
            Y, X, B_prior, V_prior, k, p, irf_horizon, sign_restrictions
        )

        # === Posterior Summaries ===
        mean_B, mean_Sigma, mean_P, mean_irfs, mean_fevd = BSVAR_functions.summarize_posteriors(
            B_draws, Sigma_draws, P_draws, irfs, fevd, columns, p
        )

        # === Confidence Intervals for IRFs and FEVDs ===
        lower_irfs = np.percentile(irfs, 2.5, axis=0)
        upper_irfs = np.percentile(irfs, 97.5, axis=0)
        lower_fevd = np.percentile(fevd, 2.5, axis=0)
        upper_fevd = np.percentile(fevd, 97.5, axis=0)

        # === Visualization ===
        BSVAR_functions.plot_irfs(mean_irfs, lower_irfs, upper_irfs, inflation_idx, k, columns)
        BSVAR_functions.plot_fevd(mean_fevd, lower_fevd, upper_fevd, inflation_idx, k, columns)

        # === Print Posterior Point Estimates ===
        print("\nPoint Estimates (Posterior Means):")
        print("B:\n", mean_B)
        print("\nSigma:\n", mean_Sigma)
        print("\nP:\n", mean_P)

        # === Credible Intervals ===
        results = BSVAR_functions.compute_and_print_credible_intervals(B_draws, Sigma_draws, P_draws)

        # === Rolling Forecast ===
        print("\nRunning rolling SVAR forecast...")
        window_size = 90
        steps_ahead = 6
        num_draws = 500

        rolling_results = BSVAR_functions.rolling_svar_forecast_bayesian_steps(
            data=filtered_df,
            window_size=window_size,
            steps_ahead=steps_ahead,
            irf_horizon=irf_horizon,
            num_draws=num_draws,
            p=p,
            columns=columns
        )
        print("Rolling forecast complete.")

        for res in rolling_results:
            if res is not None:
                print(f"Forecast for step {res['forecast_step_index']}: {res['forecast']}")
            else:
                print("Forecast failed for a window.")

        # === Forecast Output DataFrame ===
        forecast_df = pd.DataFrame([
            {
                "start": res["start_index"],
                "end": res["end_index"],
                **{f"var_{i}": val for i, val in enumerate(res["forecast"])}
            }
            for res in rolling_results if res is not None
        ])
        print(forecast_df.head())
        print("Forecasting complete.")

        # === Plot Forecasts with Confidence Intervals ===
        BSVAR_functions.plot_forecasts_with_ci(rolling_results, filtered_df, 'growth_rate_inflation', var_index=0)

        # === Evaluate Forecast ===
        rmse = BSVAR_functions.compute_rmse_rolling(rolling_results, filtered_df, 'growth_rate_inflation')
        print(f"RMSE for 'growth_rate_inflation': {rmse:.4f}")




if __name__ == "__main__":
    main()
