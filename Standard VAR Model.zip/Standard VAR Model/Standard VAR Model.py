#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import scale

# CONFIGURATION SECTION

file_path = r'C:\Users\George Tziapouras\Desktop\BSc^2 year 4\Seminar in forecasting\RECOVERY\Stationary_data_mine (10)-2Final.xlsx'

# Variable we're forecasting: inflation growth rate
target_var = 'growth rate inflation'

# Forecasting horizons to evaluate: 1-month, 3-month, and 6-month ahead
forecast_horizons = [1, 3, 6]

# Size of the rolling window used for training in each iteration
window_size = 95

# VAR model lag order (VAR(1))
lags = 1

# VARIABLE SCENARIOS

# Scenario 1: Includes demand-side and supply-side variables
scen1_vars = ['growth rate inflation', 'EUR-USD_logdiff', 'DSPIC96_log_diff', 'Brent_logdiff', 'Gas Prices_logdiff']

# Scenario 2: Reduced model (mostly demand-side)
scen2_vars = ['growth rate inflation', 'EUR-USD_logdiff', 'DSPIC96_log_diff']

# Scenario 3: Full specification with broader indicators
scen3_vars = ['growth rate inflation', 'GECON index', 'EUR-USD_logdiff', 'InterestDiff', 'DSPIC96_log_diff', 'Brent_logdiff', 'Gas Prices_logdiff']

# Dictionary to store all variable scenarios
all_var_sets = {
    "Scenario 1": scen1_vars,
    "Scenario 2": scen2_vars,
    "Scenario 3": scen3_vars
}

# DATA LOADING & PREPARATION

df = pd.read_excel(file_path, engine='openpyxl')

# Convert 'Months' column to datetime format
df['Months'] = pd.to_datetime(df['Months'])

# Remove duplicate timestamps
df = df[~df['Months'].duplicated(keep='first')]

# Set datetime index
df.set_index('Months', inplace=True)

# Assign a regular monthly frequency if possible
try:
    df = df.asfreq('MS')
except ValueError:
    print("Could not assign monthly frequency due to irregular time steps.")

# Standardize all columns to have mean=0 and std=1
df[df.columns] = scale(df[df.columns])

# Forecast Function: Rolling Forecast with VAR

def rolling_var_forecast(data, window_size, lags, forecast_horizon):
    """
    Generates rolling forecasts using a VAR model.
    For each rolling window:
    - Fit a VAR model
    - Forecast the target variable h steps ahead
    - Store the forecast for evaluation
    """
    results = []
    n_obs = data.shape[0]

    for start in range(n_obs - window_size - forecast_horizon + 1):
        end = start + window_size
        window_data = data.iloc[start:end]

        try:
            model = VAR(window_data)
            var_res = model.fit(lags)
            last_obs = window_data.values[-lags:]
            forecast = var_res.forecast(last_obs, steps=forecast_horizon)
            results.append({
                "forecast": forecast[-1],  # Save forecast at final step h
                "forecast_index": end + forecast_horizon - 1  # Future index for alignment
            })
        except Exception as e:
            print(f"Window {start}-{end} failed: {e}")
            results.append(None)

    return results

# COMPARISON FUNCTION: Preparing forecasted values vs actual values for RMSE calculation

def build_forecast_vs_actual(results, original_data):
    """
    Align forecasted values with actual values from the dataset.
    Returns a combined DataFrame with both for RMSE calculation.
    """
    forecasts = []
    actuals = []
    indices = []

    for r in results:
        if r is None:
            continue
        idx = r['forecast_index']
        if idx >= len(original_data):
            continue
        forecasts.append(r['forecast'])
        actuals.append(original_data.iloc[idx].values)
        indices.append(original_data.index[idx])

    forecast_df = pd.DataFrame(forecasts, index=indices, columns=original_data.columns)
    actual_df = pd.DataFrame(actuals, index=indices, columns=original_data.columns)

    df_comparison = pd.concat({'forecast': forecast_df, 'actual': actual_df}, axis=1)
    return df_comparison

# RSME FUNCTION

def compute_rmse(comp_df):
    """
    Compute RMSE between forecasted and actual values.
    """
    mse = ((comp_df["forecast"] - comp_df["actual"]) ** 2).mean()
    return np.sqrt(mse)

# FORECAST PLOTTING FUNCTION: Plot Forecasted vs Actual inflation growth rate values

def plot_forecast_vs_actual(comp_df, target_col):
    """
    Visual comparison between forecasted and actual values for a given variable.
    """
    plt.figure(figsize=(10, 5))
    plt.plot(comp_df.index, comp_df["actual"][target_col], label="Actual", marker='o')
    plt.plot(comp_df.index, comp_df["forecast"][target_col], label="Forecast", linestyle='--', marker='x')
    plt.title(f'Forecast vs Actual for {target_col}')
    plt.xlabel('Date')
    plt.ylabel(target_col)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

# EXECUTION LOOP: Running all forecasting and RMSE functions for all scenarios

rmse_table = {}

for scenario_name, variables in all_var_sets.items():
    # Subset and drop missing values
    df_scen = df[variables].dropna()
    rmse_table[scenario_name] = {}

    print(f"\n====== {scenario_name} ======\n")
    for horizon in forecast_horizons:
        # Forecasting loop for this scenario and horizon
        results = rolling_var_forecast(df_scen, window_size, lags, forecast_horizon=horizon)
        comp_df = build_forecast_vs_actual(results, df_scen)

        # Extract only inflation column from multi-index
        inflation_df = comp_df.xs(target_var, axis=1, level=1)

        # Print how many forecasts were made
        num_forecasts = inflation_df.dropna().shape[0]
        print(f"Generated {num_forecasts} forecasts for {horizon}-step ahead in {scenario_name}")

        # Calculate and store RMSE
        rmse = np.sqrt(((inflation_df['forecast'] - inflation_df['actual']) ** 2).mean())
        rmse_table[scenario_name][f"{horizon}-step"] = rmse

        print(f"{horizon}-Step Ahead RMSE for {target_var}: {rmse:.4f}\n")

        # Optionally plot forecast vs actual
        plot_forecast_vs_actual(comp_df, target_col=target_var)

# RMSE SUMMARY TABLE FOR DIFFERENT FORECASTING HORIZONS

rmse_summary = pd.DataFrame(rmse_table)
print("\n======= RMSE Summary (Rows: Horizons | Cols: Scenarios) =======")
print(rmse_summary)

